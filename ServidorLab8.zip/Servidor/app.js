const express = require('express');
const app = express();

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));


app.listen(3000, () =>console.log("http://localhost:3000/menu"));



app.get('/menu', (req, res) => res.render('menu'));
app.get('/cadastro', (req, res) => res.render('cadastro'));

app.post('/registrar_dados', async (req, res) => {

    console.log("Salvo!");
    res.send("Cadastrado!");
});

app.post('/login', async (req, res)=>{

    const nome = req.body.usuario;

    res.render("logado", { nome });
})